#!/usr/bin/python3

'''
by the incredible Angulion (andreas.moeglich@uni-bayreuth.de)

Takes a qblast xml file as input. Then parses the entries such that:
- they match a reference sequence at specified positions
- they differ from a reference sequence at other positions

Then writes desired sequences to text file.

'''

from Bio.Blast import NCBIXML
import os.path
import re

def wrapper(QUERY_SEQUENCE, QBLAST_RESULT_FILE, OUTPUT_FILE, POSITIONS_REQUIRED, TOLERANCE=0, POSITIONS_AVOID=[]):
  
  # variables
  positives = []
  positiveSequences = {}
  allSequences = {}
  NUMPOS = len(POSITIONS_REQUIRED)
  
  #
  if(os.path.isfile(QBLAST_RESULT_FILE)):
    # parse actual alignments to check for identities
    blast_handle = open(QBLAST_RESULT_FILE)
    blast_record = NCBIXML.parse(blast_handle)
    
    # report which positions will be checked
    red = ''
    for entry1 in POSITIONS_REQUIRED:
      red += entry1 + ':' + QUERY_SEQUENCE[int(entry1) - 1] + '; '
    
    avoidstr = ''
    for entry1 in POSITIONS_AVOID:
      avoidstr += entry1 + ':' + QUERY_SEQUENCE[int(entry1) - 1] + '; '
       
    # read data from BLAST records
    print('Checking BLAST data for ... ' + red[:-2])
    print('Tolerance ... ' + str(TOLERANCE))
    print('Avoid positions ... ' + avoidstr[:-2])
    
    outstr = ''
    for record in blast_record:
      totalnum = len(record.alignments)
      for entry1 in record.alignments:
        # determine identifier
        mt = re.match('^[^|]+\|([^\|]+)\|', entry1.title)
        if (mt):
          ident = mt.group(1)
          for entry2 in entry1.hsps:
            # extract alignment info
            query = entry2.query
            query_start = int(entry2.query_start)
            sbjct = entry2.sbjct
            sbjct_start = int(entry2.sbjct_start)
            
            # strip gap positions from both Query and Sbjct
            strip_sbjct = [sbjct[i] for i in range(len(sbjct)) if query[i] != '-']
            strip_sbjct = ''.join(strip_sbjct)
            strip_query = query.replace('-', '')
                                    
            # count number of matches b/w query and sbjct at POSITIONS_REQUIRED
            matchcount = 0
            for entry3 in POSITIONS_REQUIRED:
              # check whether still in alignment
              if (int(entry3) - query_start < len(strip_query)):
                if (int(entry3) >= query_start):
                  if (strip_query[int(entry3) - query_start] == strip_sbjct[int(entry3) - query_start]):
                    matchcount += 1

            if (matchcount >= NUMPOS - TOLERANCE):
              # first check passed
              matchcount = 0
              for entry3 in POSITIONS_AVOID:
                # check whether still in alignment
                if (int(entry3) - query_start < len(strip_query)):
                  if (int(entry3) >= query_start):
                    if (strip_query[int(entry3) - query_start] == strip_sbjct[int(entry3) - query_start]):
                      matchcount += 1
                else:
                  # if we are out of the alignment, we need to count this as a match b/c otherwise we generate false positives galore
                  matchcount += 1
              if (not matchcount):
                positives.append(ident)
                positiveSequences[ident] = sbjct
               # and now do some print out
                sbjct = sbjct.replace('-', '')
                outstr += '>' + ident + '/' + str(sbjct_start) + '-' + str(sbjct_start + len(sbjct) - 1) + '\n'
                outstr += sbjct + '\n'

            # store sequence in allSequences
            useKey = ident + '/' + str(sbjct_start) + '-' + str(sbjct_start + len(sbjct) - 1)
            allSequences[useKey] = sbjct
    
    #print positives
    blast_handle.close()   
  else:
    print('Fatal error - cannot find ' + QBLAST_RESULT_FILE)
  
  # save all sequences to file
  seq_out = open(OUTPUT_FILE, 'w')
  for ident in positiveSequences:
    seq_out.write('>' + ident + '\n' + positiveSequences[ident] + '\n')
  seq_out.close()

  # print brief statistics
  #print(outstr + '\n')
  print('Out of ' + str(totalnum) + ' entries, ' + str(len(set(positives))) + ' passed.')
  print('Written hits to ... ' + OUTPUT_FILE + '.')
  print('Done.')

#
#
#

if __name__ == "__main__":
  # the reference sequence to compare against
  QUERY_SEQUENCE = 'MASFQSFGIPGQLEVIKKALDHVRVGVVITDPALEDNPIVYVNQGFVQMTGYETEEILGKNCRFLQGKHTDPAEVDNIRTALQNKEPVTVQIQNYKKDGTMFWNELNIDPMEIEDKTYFVGIQNDIT'
  # positions within the reference sequence for which identity is required
  POSITIONS_REQUIRED = '59 61 62 63 64 65 66 94 104'.split()
  # positions that must differ from the reference sequence
  POSITIONS_AVOID = ['123']  # this would be the conserved Gln in YtvA
  # optionally, allow matching some leeway
  TOLERANCE = 0
  # the name of the qblast input file
  QBLAST_RESULT_FILE = 'qblast_results_YtvALOV_2000.xml'
  # the name of the fasta ourtput file
  OUTPUT_FILE = 'filtered_results_YtvALOV_2000.fasta'
  
  # call function
  wrapper(QUERY_SEQUENCE, QBLAST_RESULT_FILE, OUTPUT_FILE, POSITIONS_REQUIRED, TOLERANCE, POSITIONS_AVOID)